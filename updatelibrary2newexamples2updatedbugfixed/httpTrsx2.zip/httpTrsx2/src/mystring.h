/*
 * mystring.h
 *
 *  Created on: Sep 16, 2019
 *      Author: jcaf
 */

#ifndef MYSTRING_H_
#define MYSTRING_H_

int8_t charIsNumber(char c);
int8_t charIsLetter(char c);


#endif /* MYSTRING_H_ */
